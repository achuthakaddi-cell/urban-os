import React, { useEffect } from 'react';
import { useStore } from './store';
import { Onboarding } from './components/Onboarding';
import { Explore } from './components/Explore';
import { ErrorBoundary } from './components/ErrorBoundary';

export default function App() {
  const { stage, confirmSelection } = useStore();

  useEffect(() => {
    // Autostart parameter support for testability - runs once on initial mount
    const params = new URLSearchParams(window.location.search);
    if (params.get('autostart') === '1') {
      window.history.replaceState({}, '', window.location.pathname);
      confirmSelection();
    }
  }, [confirmSelection]);

  return (
    <ErrorBoundary fallbackTitle="APPLICATION ENGINE SAFEGUARD">
      <div className="w-screen h-screen overflow-hidden bg-white text-black font-sans">
        {stage === 'select' ? <Onboarding /> : <Explore />}
      </div>
    </ErrorBoundary>
  );
}
